RsInstrument module provides convenient way of communicating with R&S instruments.

The RsInstrument package is hosted on pypi.org:
https://pypi.org/project/RsInstrument/

Check out the full documentation here including the installation instructions:
https://rsinstrument.readthedocs.io/