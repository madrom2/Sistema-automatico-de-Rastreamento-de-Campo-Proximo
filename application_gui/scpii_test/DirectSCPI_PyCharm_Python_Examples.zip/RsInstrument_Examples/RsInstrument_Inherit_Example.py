# This example show a definition of a simple inherited class MyRsInstrument that extends the RsInstrument functionalities
# In this case we simple map two methods to new names: write_str() -> write() and query_str() -> query()

from RsInstrument import *  # The RsInstrument package is hosted on pypi.org, see Readme.txt for more details
from typing import Optional


class MyRsInstrument(RsInstrument):
	"""Example of an inherited class to add new methods"""
	def __init__(self, resource_name: str, id_query: bool = True, reset: bool = False, options: Optional[str] = None, direct_session: Optional[object] = None) -> None:
		super().__init__(resource_name, id_query, reset, options, direct_session)

	def write(self, cmd: str) -> None:
		"""Writes string command"""
		self.write_str(cmd)

	def query(self, query: str) -> str:
		"""Sends the query to the instrument and returns the response as string.
		The response is trimmed of any trailing LF characters and has no length limit."""
		return self.query_str(query)


RsInstrument.assert_minimum_version('1.10.0')
instr = MyRsInstrument("TCPIP::10.112.1.179::INSTR", True, False)
instr.write("*RST")
idn = instr.query('*IDN?')
print(f"\nHello, I am: '{idn}'")

instr.close()
